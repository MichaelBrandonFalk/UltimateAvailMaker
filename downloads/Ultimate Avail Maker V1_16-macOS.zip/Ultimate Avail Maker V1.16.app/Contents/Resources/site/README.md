# Ultimate Avail Maker

Current public version: `V1_16`.

Public browser version: https://michaelbrandonfalk.github.io/UltimateAvailMaker/

Ultimate Avail Maker is a browser-based local tool for creating and converting avails workbooks.

## Outputs

- Standard EMA movie avails.
- Standard EMA TV episode avails.
- YouTube-style movie avails.
- YouTube-style TV episode avails.
- Optional WhatsOn/Rally-style upload import to populate Movie and TV fields before dates are added.
- Optional Metadata Smart Sheet import to populate dates and blank fields from a secondary or sole source.
- Multi-season TV uploads can be exported in one TV avail.
- Multi-season TV uploads are sorted by season number and each episode row uses the matching season row's `VOD ID SKU`.
- Preview tables show every output field and can be copied with or without headers.
- Clear buttons reset each tab's inputs, upload selection, status, and preview.
- Movie and TV top-level Start Date and End Date fields include full-click calendar buttons that populate the adjacent date field.
- Standard EMA to YouTube conversion from pasted rows or uploaded `.xlsx`, `.xls`, `.csv`, `.tsv`, or `.txt` files.
- YouTube to Standard EMA conversion is also supported for matching rows.

## Movie Inputs

- Optional WhatsOn Upload file (`.xlsx`, `.xls`, `.csv`, `.tsv`, or `.txt`)
- Optional Metadata Smart Sheet file (`.xlsx`, `.xls`, `.csv`, `.tsv`, or `.txt`)
- Title
- SKU
- Start date
- End date
- Optional Gracenote ID, written to `RetailerID1`

## TV Inputs

- Optional WhatsOn Upload file (`.xlsx`, `.xls`, `.csv`, `.tsv`, or `.txt`)
- Optional Metadata Smart Sheet file (`.xlsx`, `.xls`, `.csv`, `.tsv`, or `.txt`)
- Series name
- Season number
- Series SKU
- Season SKU
- Start date
- End date
- Optional Gracenote Show ID, written to `RetailerSeriesID`
- Episode rows:
  - Season number
  - Season SKU
  - Episode number
  - Episode name
  - Episode SKU
  - Optional Gracenote Episode ID, written to `RetailerEpisodeID1`
  - Optional per-episode Start date and End date

The TV-level Season number, Season SKU, Start date, and End date are used as fallback values for episode rows. Use the apply-date buttons to copy the TV-level date to every episode row.

Date fields accept pasted values such as `6/10/2029`, `2029-06-10`, or `June 10, 2029`, and export as `yyyy-mm-dd`.

Any date value containing `TBD` is treated as blank. The app never guesses a date from partial text such as `TBD 12/26`, `TBD Jan 2027`, or `09/30/2026 /TBD`.

WhatsOn movie uploads populate the movie SKU from `VOD ID SKU`. For example, `An Ozark Mountain Christmas.xlsx` imports SKU `1fe20853-ec64-585c-8d22-26d1eecd207c`.

## Output File Names

Downloads use the source upload name when available, otherwise the entered title or series name.

- Standard EMA: `FileName_Avails_YYYY_MM_DD_a.xlsx`
- YouTube: `YT_FileName_Avails_YYYY_MM_DD_a.xlsx`

For example, uploading `Princess Cut.xlsx` on July 31, 2026 creates `PrincessCut_Avails_2026_07_31_a.xlsx` for Standard EMA and `YT_PrincessCut_Avails_2026_07_31_a.xlsx` for YouTube.

## WhatsOn Upload Mapping

Native WhatsOn uploads use these fields:

- `Content type`: `Program` becomes Movie, `Parent series` becomes the series row, `Series` becomes the season row, and `Episode` becomes episode rows.
- `VOD ID SKU`: SKU for movie, series, season, or episode rows when present.
- `Parent series`: series name.
- `Title`: movie title, season title, or episode title depending on row type.
- `Season`: season number. Values like `1.0` are written as `1`.
- `Episode #`: episode number. Season-prefixed values are normalized inside the season, so `101` becomes `1` and `225` becomes `25`.

For a native WhatsOn season row where `Content type` is `Series`, the app matches by the `Season` column and uses that row's `VOD ID SKU` as the Season SKU. `External reference` is only a last fallback if the season row has no usable VOD SKU.

If a WhatsOn upload contains multiple seasons for the same series, all seasons are loaded into the episode table and exported together. For example, `Curated for H.E.R.` season 2 uses Season SKU `4dda940e-5433-5169-bb3f-c8841ba492ed`.

For a four-season WhatsOn upload such as `Carpooling with Jesus Season 1 through 4 .xlsx`, the app exports seasons 1 through 4 in order and applies the correct season SKU to each episode row.

## Metadata Smart Sheet Mapping

WhatsOn remains the primary import source when both files are loaded. Metadata Smart Sheet imports fill blank fields, including blank Start Date and End Date fields, from these columns:

- `VOD Start Date`: Start Date when populated
- `PF Premiere Date`: Start Date fallback when `VOD Start Date` is blank
- `Term End Date`: End Date
- `Title`: Movie title, TV series title, or episode title depending on row type
- `Type`: `Movie` uses the Movie tab. `Series`, `TVSHOW`, `Season`, `Episode`, and `Podcast` use the TV tab. `Podcast` is treated as a series-level row.
- `New SKU`: Only allowed Metadata Smart Sheet source for movie, series, season, and episode SKU fields
- `External ID (Generated)`: Ignored

If Metadata Smart Sheet is uploaded without WhatsOn, the app chooses the first matching movie or TV series group it can read and populates as much as possible. If a TV series already has WhatsOn episode rows loaded, Metadata Smart Sheet episode rows are matched by SKU or by season plus episode number, then used to fill blanks. Populated WhatsOn or user-entered fields are left unchanged, and no new episode rows are created alongside WhatsOn rows.

## YouTube End Date Clamp

YouTube output dates are converted from New York availability dates to UTC timestamps.

Any YouTube end date later than `2036-01-02` is clamped to the New York end-of-day timestamp for `2036-01-02`, which exports as:

```text
2036-01-03T04:59:59Z
```

## Desktop Apps

The website provides self-contained desktop packages for macOS, Windows, and Linux Mint. Every package bundles the complete interface and spreadsheet engine, opens in its own application window, and does not require a browser, Node.js, or Python.

- macOS: Download `Ultimate Avail Maker V1_16-macOS.zip`, unzip it, and double-click `Ultimate Avail Maker V1.16.app`. The universal app supports Apple silicon and Intel Macs. If macOS blocks the first launch, Control-click the app, choose **Open**, then confirm **Open**.
- Windows: Download `Ultimate-Avail-Maker-V1_16-Windows-x64.exe` and double-click it. This is a portable 64-bit app and does not require installation. If Microsoft Defender SmartScreen appears, choose **More info**, then **Run anyway**.
- Linux Mint: Download `Ultimate-Avail-Maker-V1_16-Linux-Mint-amd64.deb` and open it with Software Manager to install the app. The GitHub release also includes a self-contained AppImage; mark it as executable in file Properties before opening it.

For repository development, open `index.html` directly or run a local static server:

```bash
python3 -m http.server 8765
```

Then open:

```text
http://localhost:8765/
```

## Versioned Build

Run the versioned build script from this directory:

```bash
./build_ultimate_avail_maker_v1_16.sh
```

The script creates:

```text
downloads/Ultimate Avail Maker V1_16-macOS.zip
```

The ZIP contains one clickable universal macOS app bundle for Apple silicon and Intel Macs. The script refuses to overwrite an existing app build or ZIP. Windows and Linux packages are built on their native GitHub Actions runners from `package.json` and `.github/workflows/desktop-release.yml`.

## Browser Version

The same `index.html` is the browser version and can be hosted as a static GitHub Pages site.

## Tests

```bash
node tests/core.test.js
node tests/sample_workbooks_smoke.js
```
